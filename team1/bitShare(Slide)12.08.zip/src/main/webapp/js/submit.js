function addUserSubmit(){  
	document.addUserForm.submit(); 
}

function updateUserSubmit(){
	document.updateUserForm.submit();	
}

function loginSubmit(){
	document.loginForm.submit();			 
}
function logoutUserSubmit(){
	document.logoutForm.submit();
}

function addContentSubmit() {

	document.addContentForm.submit();

}